# ApolloCare Pharmacy - Online Medicine Store

A full-stack web application for an online pharmacy with medicine ordering, prescription management, and inventory tracking.

## Features

- **User Management**: Registration, login, and profile management
- **Medicine Catalog**: Browse and search medicines by name, brand, category
- **Shopping Cart**: Add medicines to cart and manage quantities
- **Order Management**: Place orders, view order history, track delivery
- **Prescription Upload**: Upload and verify prescriptions
- **Staff Dashboard**: Inventory management, prescription verification, order tracking
- **Real-time Inventory**: Stock tracking with expiry date monitoring

## Tech Stack

- **Frontend**: HTML, CSS, JavaScript (Vanilla)
- **Backend**: Node.js, Express.js
- **Database**: SQLite
- **File Upload**: Multer

## Prerequisites

- Node.js (v14 or higher)
- npm (comes with Node.js)

## Installation

1. **Clone or download the project**
   ```bash
   cd ApolloCare
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Initialize the database**
   ```bash
   npm run init-db
   ```
   This will create the database with sample data including:
   - Sample medicines
   - Sample categories
   - Sample user (john@example.com / user123)
   - Sample staff (alex@apollocare.com / staff123)

4. **Start the server**
   ```bash
   npm start
   ```
   The server will run on `http://localhost:3000`

5. **Open the application**
   - Open your browser and navigate to `http://localhost:3000`
   - Or open `index.html` directly (some features require the server)

## Default Login Credentials

### User Account
- **Email**: john@example.com
- **Password**: user123

### Staff Account
- **Email**: alex@apollocare.com
- **Password**: staff123

## Project Structure

```
ApolloCare/
├── database/
│   ├── schema.sql          # Database schema
│   ├── init.js             # Database initialization script
│   └── apollocare.db       # SQLite database (created after init)
├── uploads/
│   └── prescriptions/      # Uploaded prescription files
├── css/
│   └── style.css           # Main stylesheet
├── js/
│   └── script.js           # Frontend JavaScript with API integration
├── server.js               # Express backend server
├── package.json            # Node.js dependencies
└── *.html                  # HTML pages
```

## API Endpoints

### Authentication
- `POST /api/register` - User registration
- `POST /api/login` - User login
- `POST /api/staff/login` - Staff login

### Medicines
- `GET /api/medicines` - Get all medicines (supports ?q=search&category=name)
- `GET /api/medicines/:id` - Get medicine by ID
- `GET /api/categories` - Get all categories

### Orders
- `POST /api/orders` - Create new order (requires auth)
- `GET /api/orders` - Get user orders (requires auth)
- `GET /api/orders/:id` - Get order details (requires auth)
- `GET /api/staff/orders` - Get all orders (staff)

### Prescriptions
- `POST /api/prescriptions` - Upload prescription (requires auth)
- `GET /api/prescriptions` - Get user prescriptions (requires auth)
- `GET /api/staff/prescriptions` - Get all prescriptions (staff)
- `PATCH /api/staff/prescriptions/:id` - Update prescription status

### Profile
- `GET /api/profile` - Get user profile (requires auth)
- `PATCH /api/profile` - Update user profile (requires auth)

### Inventory (Staff)
- `GET /api/staff/inventory` - Get all medicines
- `PATCH /api/staff/medicines/:id` - Update medicine stock/price
- `GET /api/staff/dashboard` - Get dashboard statistics

## Usage Guide

### For Customers

1. **Browse Medicines**: Visit the home page or search page to browse available medicines
2. **Add to Cart**: Click "Add" on any medicine to add it to your cart
3. **View Cart**: Click the cart icon to view and manage items
4. **Checkout**: Proceed to checkout, fill in delivery details, and place order
5. **Track Orders**: View order history and track delivery status
6. **Upload Prescription**: Upload doctor's prescription for verification

### For Staff

1. **Login**: Use staff credentials to login
2. **Dashboard**: View key metrics and recent orders
3. **Inventory**: Manage medicine stock levels and prices
4. **Prescription Verification**: Review and approve/reject uploaded prescriptions
5. **Order Management**: View and manage all customer orders

## Development

### Running in Development Mode

```bash
npm run dev
```
This uses nodemon to automatically restart the server on file changes.

### Database Schema

The database includes the following tables:
- `users` - Customer accounts
- `staff` - Staff accounts
- `categories` - Medicine categories
- `medicines` - Medicine inventory
- `orders` - Customer orders
- `order_items` - Order line items
- `prescriptions` - Uploaded prescriptions
- `sessions` - Authentication sessions

### Adding New Medicines

You can add medicines through the inventory page (staff) or directly in the database:

```sql
INSERT INTO medicines (medicine_id, name, brand, category_id, price, stock, batch, expiry_date, composition, image_url)
VALUES ('MED009', 'Medicine Name', 'Brand', 1, 100, 50, 'BATCH-X1', '2026-12-31', 'Active Ingredient', 'image_url');
```

## Troubleshooting

### Database not found
- Run `npm run init-db` to create and initialize the database

### Port already in use
- Change the PORT in `server.js` or set environment variable: `PORT=3001 npm start`

### CORS errors
- Make sure the server is running and accessible at `http://localhost:3000`

### Upload errors
- Ensure the `uploads/prescriptions/` directory exists and has write permissions

## Notes

- The application uses SQLite for simplicity - no separate database server required
- Passwords are stored as base64 (for demo purposes) - use bcrypt in production
- File uploads are stored in the `uploads/` directory
- The cart is stored in browser localStorage
- Authentication tokens expire after 7 days

## License

This project is for educational/demonstration purposes.

## Support

For issues or questions, please check the code comments or contact the development team.



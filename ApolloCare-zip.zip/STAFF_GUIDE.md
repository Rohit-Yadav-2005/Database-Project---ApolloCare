# Staff Functionality Guide

## How to Use Staff Order Management

### Step 1: Staff Login

1. Go to: `http://localhost:3000/staff-login.html`
2. Enter staff credentials:
   - **Email**: `alex@apollocare.com`
   - **Password**: `staff123`
3. Click "Sign In"

### Step 2: Access Staff Dashboard

After login, you'll be redirected to the Staff Dashboard where you can:
- View key metrics (Pending Rx, Orders Today, Low Stock, etc.)
- See recent orders
- Access quick actions

### Step 3: Manage Orders

1. Click **"Manage Orders"** button in Quick Actions
2. Or go directly to: `http://localhost:3000/staff-orders.html`

### Step 4: Update Order Status

On the Manage Orders page:

1. **View all orders** in a table format
2. **Search orders** by Order ID or Customer name
3. **Filter by status** using the dropdown
4. **Update status** using the dropdown in the "Actions" column:
   - Select new status: Processing → Shipped → Out for Delivery → Delivered
   - Status updates automatically
   - Customer will see updated status in their order history

## Available Order Statuses

- **Processing** - Order being prepared (default)
- **Shipped** - Order dispatched
- **Out for Delivery** - With delivery partner
- **Delivered** - Successfully delivered
- **Cancelled** - Order cancelled

## Features

✅ **View All Orders** - See all customer orders
✅ **Search Orders** - Find orders by ID or customer name
✅ **Filter by Status** - Filter orders by current status
✅ **Update Status** - Change order status with dropdown
✅ **Real-time Updates** - Changes reflect immediately
✅ **Order Details** - Click Order ID to view full invoice

## Staff Credentials

- **Email**: `alex@apollocare.com`
- **Password**: `staff123`

Or:

- **Email**: `riya@apollocare.com`
- **Password**: `staff123`

## Workflow Example

1. Customer places order → Status: **Processing**
2. Staff prepares order → Update to: **Shipped**
3. Order with courier → Update to: **Out for Delivery**
4. Order delivered → Update to: **Delivered**

## Notes

- Only staff members can access order management
- Status changes are permanent and visible to customers
- Order history shows all status changes
- Staff can view order details by clicking Order ID


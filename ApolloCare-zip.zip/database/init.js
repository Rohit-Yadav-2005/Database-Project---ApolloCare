const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'apollocare.db');
const schemaPath = path.join(__dirname, 'schema.sql');

// Create database directory if it doesn't exist
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
}

// Read schema
const schema = fs.readFileSync(schemaPath, 'utf8');

// Initialize database
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
        process.exit(1);
    }
    console.log('Connected to SQLite database.');
});

// Execute schema
db.exec(schema, (err) => {
    if (err) {
        console.error('Error creating schema:', err.message);
        db.close();
        process.exit(1);
    }
    console.log('Database schema created successfully.');
    
    // Insert sample data
    insertSampleData();
});

function insertSampleData() {
    // Insert categories
    const categories = [
        'Cold & Cough', 'Diabetes', 'Heart Care', 'Pain Relief', 
        'Vitamins', 'Baby Care', 'Skin Care', 'Ayurveda', 'Allergy', 'Digestive'
    ];
    
    const categoryStmt = db.prepare('INSERT OR IGNORE INTO categories (name) VALUES (?)');
    categories.forEach(cat => categoryStmt.run(cat));
    categoryStmt.finalize();
    
    // Get category IDs
    db.all('SELECT id, name FROM categories', (err, cats) => {
        if (err) {
            console.error('Error fetching categories:', err);
            return;
        }
        
        const categoryMap = {};
        cats.forEach(c => categoryMap[c.name] = c.id);
        
        // Insert medicines
        const medicines = [
            { id: 'MED001', name: 'Paracetamol 500mg', brand: 'MediLife', category: 'Pain Relief', price: 49, stock: 120, batch: 'BATCH-A1', expiry: '2026-03-31', composition: 'Paracetamol', image: 'https://www.lxir.in/wp-content/uploads/2024/02/HECHOPYRIN-500.png' },
            { id: 'MED002', name: 'Cetirizine 10mg', brand: 'HealWell', category: 'Allergy', price: 35, stock: 80, batch: 'BATCH-C3', expiry: '2026-10-10', composition: 'Cetirizine', image: 'https://cdn.foxpharma.co.uk/wp-content/uploads/2024/09/Cetirizine-10mg.jpg' },
            { id: 'MED003', name: 'Metformin 500mg', brand: 'GlucoCare', category: 'Diabetes', price: 75, stock: 60, batch: 'BATCH-M5', expiry: '2027-02-15', composition: 'Metformin', image: 'https://5.imimg.com/data5/SELLER/Default/2024/12/474243673/MH/AE/VI/234812122/500mg-metformin-hydrochloride-tablet-ip.webp' },
            { id: 'MED004', name: 'Vitamin C 1000mg', brand: 'NutraPlus', category: 'Vitamins', price: 120, stock: 150, batch: 'BATCH-V2', expiry: '2027-11-20', composition: 'Ascorbic Acid', image: 'https://www.healthcarebeauty.in/UploadImages/7bbb43e2-b1e4-4430-b892-0de02c899e1e_big.jpg' },
            { id: 'MED005', name: 'Cough Syrup 100ml', brand: 'Respira', category: 'Cold & Cough', price: 89, stock: 45, batch: 'BATCH-R8', expiry: '2025-09-01', composition: 'Dextromethorphan', image: 'https://m.media-amazon.com/images/I/61DYD3i7WrL.jpg' },
            { id: 'MED006', name: 'Omeprazole 20mg', brand: 'GastroCare', category: 'Digestive', price: 65, stock: 90, batch: 'BATCH-O4', expiry: '2026-08-15', composition: 'Omeprazole', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSoU2YnQhwcp4T54WguU2FlwIEYUjvrT8QBaQ&s' },
            { id: 'MED007', name: 'Amlodipine 5mg', brand: 'CardioPlus', category: 'Heart Care', price: 95, stock: 70, batch: 'BATCH-AM2', expiry: '2027-01-20', composition: 'Amlodipine', image: 'https://5.imimg.com/data5/SELLER/Default/2023/7/326770036/BL/UA/BR/135658020/amlodipine-tablets-ip-5-mg.jpg' },
            { id: 'MED008', name: 'Multivitamin Tablets', brand: 'VitaMax', category: 'Vitamins', price: 180, stock: 110, batch: 'BATCH-MV7', expiry: '2027-06-30', composition: 'Multiple Vitamins', image: 'https://pacome.in/wp-content/uploads/2024/07/Immunity-and-Health-Booster-1.jpg' },
        ];
        
        const medStmt = db.prepare(`
            INSERT OR IGNORE INTO medicines 
            (medicine_id, name, brand, category_id, price, stock, batch, expiry_date, composition, image_url)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        medicines.forEach(med => {
            const catId = categoryMap[med.category] || null;
            medStmt.run(
                med.id, med.name, med.brand, catId, med.price, 
                med.stock, med.batch, med.expiry, med.composition, med.image
            );
        });
        medStmt.finalize();
        
        // Insert sample staff
        const staffStmt = db.prepare(`
            INSERT OR IGNORE INTO staff (name, email, password, role)
            VALUES (?, ?, ?, ?)
        `);
        
        // Using simple password hash (in production, use bcrypt)
        const hashPassword = (pwd) => Buffer.from(pwd).toString('base64');
        
        staffStmt.run('Alex Patel', 'alex@apollocare.com', hashPassword('staff123'), 'Pharmacist');
        staffStmt.run('Riya Das', 'riya@apollocare.com', hashPassword('staff123'), 'Verifier');
        staffStmt.finalize();
        
        // Insert sample user (password: user123)
        const userStmt = db.prepare(`
            INSERT OR IGNORE INTO users (first_name, last_name, email, phone, password, address)
            VALUES (?, ?, ?, ?, ?, ?)
        `);
        
        userStmt.run('John', 'Doe', 'john@example.com', '+1 234 567 8900', hashPassword('user123'), '123 Main Street, City, State 12345');
        userStmt.finalize();
        
        console.log('Sample data inserted successfully.');
        console.log('\nSample Login Credentials:');
        console.log('User: john@example.com / user123');
        console.log('Staff: alex@apollocare.com / staff123');
        
        db.close((err) => {
            if (err) {
                console.error('Error closing database:', err.message);
            } else {
                console.log('\nDatabase initialization complete!');
            }
        });
    });
}




// Migration script to add cart table to existing database
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'apollocare.db');

if (!fs.existsSync(dbPath)) {
    console.log('Database not found. Run npm run init-db first.');
    process.exit(0);
}

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
        process.exit(1);
    }
    console.log('Connected to database.');
});

// Check if cart table exists
db.get("SELECT name FROM sqlite_master WHERE type='table' AND name='cart'", [], (err, row) => {
    if (err) {
        console.error('Error checking table:', err.message);
        db.close();
        process.exit(1);
    }
    
    if (row) {
        console.log('Cart table already exists. Migration not needed.');
        db.close();
        process.exit(0);
    }
    
    // Create cart table
    console.log('Creating cart table...');
    db.run(`
        CREATE TABLE IF NOT EXISTS cart (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            medicine_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (medicine_id) REFERENCES medicines(id),
            UNIQUE(user_id, medicine_id)
        )
    `, (err) => {
        if (err) {
            console.error('Error creating cart table:', err.message);
            db.close();
            process.exit(1);
        }
        
        // Create index
        db.run('CREATE INDEX IF NOT EXISTS idx_cart_user ON cart(user_id)', (err) => {
            if (err) {
                console.error('Error creating index:', err.message);
            }
            
            db.run('CREATE INDEX IF NOT EXISTS idx_cart_medicine ON cart(medicine_id)', (err) => {
                if (err) {
                    console.error('Error creating index:', err.message);
                }
                
                console.log('✓ Cart table created successfully!');
                console.log('✓ Migration complete!');
                db.close();
            });
        });
    });
});


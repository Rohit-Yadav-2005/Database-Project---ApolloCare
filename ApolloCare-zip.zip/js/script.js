(function(){
  const API_BASE = 'http://localhost:3000/api';
  const state = {
    cart: [],
    user: JSON.parse(localStorage.getItem('user') || 'null'),
    token: localStorage.getItem('token') || null,
    staff: JSON.parse(localStorage.getItem('staff') || 'null'),
  };

  // API helper
  async function apiCall(endpoint, options = {}) {
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers
    };
    if (state.token) {
      headers.Authorization = `Bearer ${state.token}`;
    }
    
    try {
      const response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Request failed');
      }
      return data;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  // Load cart from database
  async function loadCart() {
    if (!state.token) {
      state.cart = [];
      updateCartBadge();
      return;
    }
    
    try {
      const items = await apiCall('/cart');
      state.cart = items.map(item => ({
        id: item.id,
        medicine_id: item.medicine_id,
        name: item.name,
        price: item.price,
        image: item.image_url,
        qty: item.quantity
      }));
      updateCartBadge();
    } catch (error) {
      console.error('Error loading cart:', error);
      state.cart = [];
      updateCartBadge();
    }
  }

  async function addToCart(product, qty) {
    if (!state.token) {
      toast('Please login to add items to cart', 'error');
      window.location.href = 'login.html';
      return;
    }
    
    try {
      const medId = product.medicine_id || product.id;
      await apiCall('/cart', {
        method: 'POST',
        body: JSON.stringify({ medicineId: medId, quantity: qty })
      });
      toast(`${product.name} added to cart`);
      await loadCart(); // Reload cart from database
    } catch (error) {
      toast(error.message || 'Failed to add to cart', 'error');
    }
  }

  async function removeFromCart(cartItemId) {
    if (!state.token) return;
    
    try {
      await apiCall(`/cart/${cartItemId}`, { method: 'DELETE' });
      await loadCart(); // Reload cart from database
    } catch (error) {
      toast(error.message || 'Failed to remove item', 'error');
    }
  }

  async function updateCartQuantity(cartItemId, quantity) {
    if (!state.token) return;
    
    try {
      await apiCall(`/cart/${cartItemId}`, {
        method: 'PATCH',
        body: JSON.stringify({ quantity })
      });
      await loadCart(); // Reload cart from database
    } catch (error) {
      toast(error.message || 'Failed to update cart', 'error');
    }
  }

  function updateCartBadge(){
    const count = state.cart.reduce((a,b)=>a+b.qty,0);
    const el = document.querySelector('[data-cart-count]');
    if(el) el.textContent = count;
  }

  function headerTemplate(){
    const userLinks = state.user ? `
      <a href="order-history.html">Orders</a>
      <a href="profile.html">Profile</a>
      <a href="#" onclick="logout()">Logout</a>
    ` : `
      <a href="login.html">Login</a>
    `;
    
    const cartButton = state.user ? `
      <a class="icon-btn" href="cart.html">Cart <span class="badge" data-cart-count>0</span></a>
    ` : '';
    
    return `
    <div class="topbar">
      <div class="container">
        <div>Free delivery on orders over ₹499</div>
        <div class="row" style="gap:.8rem">
          ${userLinks}
        </div>
      </div>
    </div>
    <div class="navbar">
      <div class="container row">
        <a class="logo" href="index.html">
          <div class="mark">Rx</div>
          <span>ApolloCare</span>
        </a>
        <form class="search" action="search.html">
          <input name="q" placeholder="Search medicines, brands and more" />
          <button type="submit">Search</button>
        </form>
        <div class="actions">
          ${state.user ? '<a class="icon-btn" href="upload-prescription.html">Upload Rx</a>' : ''}
          ${cartButton}
        </div>
      </div>
    </div>`;
  }

  function footerTemplate(){
    return `
    <div class="container">
      <div>
        <a class="logo" href="index.html"><div class="mark">Rx</div><span>ApolloCare</span></a>
        <p class="mt-1 text-muted">Your trusted online pharmacy for medicines, wellness and care.</p>
      </div>
      <div>
        <h4>Company</h4>
        <div class="stack">
          <a href="#">About</a>
          <a href="#">Careers</a>
          <a href="#">Blog</a>
        </div>
      </div>
      <div>
        <h4>Support</h4>
        <div class="stack">
          <a href="#">Help Center</a>
          <a href="#">Returns</a>
          <a href="#">Contact</a>
        </div>
      </div>
      <div>
        <h4>Legal</h4>
        <div class="stack">
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">© 2025 ApolloCare.</div>
    </div>`;
  }

  async function injectLayout(){
    const header = document.createElement('div'); header.className = 'header'; header.innerHTML = headerTemplate();
    const footer = document.createElement('div'); footer.className = 'footer'; footer.innerHTML = footerTemplate();
    document.body.prepend(header);
    document.body.append(footer);
    await loadCart(); // Load cart from database
  }

  function toast(message, type = 'success'){
    let el = document.querySelector('.toast');
    if(!el){ el = document.createElement('div'); el.className = 'toast'; document.body.append(el); }
    el.textContent = message; 
    el.classList.add('show');
    if(type === 'error') el.style.background = '#ef4444';
    setTimeout(()=> { el.classList.remove('show'); el.style.background = ''; }, 2200);
  }

  window.logout = function() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('staff');
    state.token = null;
    state.user = null;
    state.staff = null;
    window.location.href = 'index.html';
  };

  // Page renders
  const renderers = {
    async home(){
      try {
        const medicines = await apiCall('/medicines?limit=8');
        const grid = document.querySelector('[data-featured]');
        if(grid) {
          grid.innerHTML = '';
          medicines.slice(0, 8).forEach(m => grid.appendChild(productCard(m)));
        }
        
        const cats = document.querySelector('[data-categories]');
        if(cats){
          const categories = await apiCall('/categories');
          categories.forEach(c => {
            const el = document.createElement('div'); 
            el.className = 'category-card'; 
            el.textContent = c.name; 
            el.onclick = () => window.location.href = `search.html?category=${c.name}`;
            cats.appendChild(el);
          });
        }
      } catch (error) {
        console.error('Error loading home:', error);
        toast('Error loading medicines', 'error');
      }
    },
    
    async search(){
      const params = new URLSearchParams(location.search);
      const q = params.get('q') || '';
      const category = params.get('category') || '';
      
      const list = document.querySelector('[data-results]');
      const term = document.querySelector('[data-term]');
      if(term) term.textContent = q || category || 'All';
      
      try {
        let endpoint = '/medicines';
        if (q) endpoint += `?q=${encodeURIComponent(q)}`;
        if (category) endpoint += q ? `&category=${encodeURIComponent(category)}` : `?category=${encodeURIComponent(category)}`;
        
        const results = await apiCall(endpoint);
        list.innerHTML = '';
        if(results.length === 0) {
          list.innerHTML = '<div class="card pad">No results found.</div>';
        } else {
          results.forEach(m => list.appendChild(productCard(m)));
        }
      } catch (error) {
        console.error('Error searching:', error);
        list.innerHTML = '<div class="card pad">Error loading results. Please try again.</div>';
      }
    },
    
    async details(){
      const params = new URLSearchParams(location.search);
      const id = params.get('id') || 'MED001';
      const root = document.querySelector('[data-details]');
      if(!root) return;
      
      try {
        const med = await apiCall(`/medicines/${id}`);
        root.innerHTML = `
          <div class="split">
            <div class="card pad center">
              <img alt="${med.name}" src="${med.image_url || med.image}" style="max-height:280px">
            </div>
            <div class="stack">
              <h2 class="m-0">${med.name}</h2>
              <div class="meta">Brand: ${med.brand} · Category: ${med.category_name || med.category}</div>
              <div class="price">₹${med.price}</div>
              <div class="meta">Batch: ${med.batch || 'N/A'} · Exp: ${med.expiry_date || 'N/A'}</div>
              <div class="meta">Stock: ${med.stock} available</div>
              <div class="row">
                <div class="qty"><label>Qty</label><input type="number" min="1" max="${med.stock}" value="1" /></div>
                <button class="btn" data-add> Add to Cart</button>
              </div>
            </div>
          </div>`;
        const qtyEl = root.querySelector('input[type="number"]');
        root.querySelector('[data-add]').addEventListener('click', ()=> {
          const qty = Math.max(1, parseInt(qtyEl.value||'1',10));
          if (qty > med.stock) {
            toast('Insufficient stock', 'error');
            return;
          }
          addToCart(med, qty);
        });
      } catch (error) {
        console.error('Error loading details:', error);
        root.innerHTML = '<div class="card pad">Medicine not found.</div>';
      }
    },
    
    async cart(){
      if (!state.token) {
        window.location.href = 'login.html';
        return;
      }
      
      const list = document.querySelector('[data-cart-list]');
      const summary = document.querySelector('[data-cart-summary]');
      if(!list) return;
      
      await loadCart(); // Load cart from database
      
      function render(){
        list.innerHTML = '';
        if(state.cart.length===0){ 
          list.innerHTML = '<div class="card pad">Your cart is empty.</div>'; 
          summary.innerHTML=''; 
          return; 
        }
        let total = 0;
        state.cart.forEach(item => {
          total += item.price * item.qty;
          const row = document.createElement('div'); 
          row.className = 'card pad';
          row.innerHTML = `
            <div class="space-between">
              <div class="row">
                <img src="${item.image}" alt="${item.name}" style="width:60px;height:60px;border-radius:8px;object-fit:cover">
                <div>
                  <div class="product title">${item.name}</div>
                  <div class="meta">₹${item.price} · Qty ${item.qty}</div>
                </div>
              </div>
              <div class="row">
                <button class="chip" data-dec data-id="${item.id}">-</button>
                <button class="chip" data-inc data-id="${item.id}">+</button>
                <button class="chip" data-rm data-id="${item.id}">Remove</button>
              </div>
            </div>`;
          row.querySelector('[data-inc]').addEventListener('click', async ()=>{ 
            await updateCartQuantity(item.id, item.qty + 1);
            render();
          });
          row.querySelector('[data-dec]').addEventListener('click', async ()=>{ 
            await updateCartQuantity(item.id, Math.max(1, item.qty - 1));
            render();
          });
          row.querySelector('[data-rm]').addEventListener('click', async ()=>{ 
            await removeFromCart(item.id);
            render();
          });
          list.appendChild(row);
        });
        const delivery = total > 499 ? 0 : 49;
        summary.innerHTML = `
          <div class="card pad checkout-summary">
            <div class="line"><span>Subtotal</span><b>₹${total.toFixed(2)}</b></div>
            <div class="line"><span>Delivery</span><b>₹${delivery.toFixed(2)}</b></div>
            <div class="line total"><span>Total</span><b>₹${(total + delivery).toFixed(2)}</b></div>
            <a class="btn mt-2" href="checkout.html">Proceed to Checkout</a>
          </div>`;
      }
      render();
    },
    
    async checkout(){
      if (!state.token) {
        window.location.href = 'login.html';
        return;
      }
      
      const sum = document.querySelector('[data-checkout-summary]');
      if(!sum) return;
      
      // Load user profile to populate form
      try {
        const user = await apiCall('/profile');
        document.getElementById('firstName').value = user.first_name || '';
        document.getElementById('lastName').value = user.last_name || '';
        document.getElementById('phone').value = user.phone || '';
        if (user.address) {
          const addrParts = user.address.split(',');
          document.getElementById('address').value = addrParts[0] || '';
          if (addrParts.length > 1) {
            document.getElementById('city').value = addrParts[1]?.trim() || '';
          }
          if (addrParts.length > 2) {
            document.getElementById('zip').value = addrParts[addrParts.length - 1]?.trim() || '';
          }
        }
      } catch (error) {
        console.error('Error loading profile:', error);
      }
      
      await loadCart(); // Load cart from database
      const total = state.cart.reduce((a,b)=>a + b.price*b.qty, 0);
      const delivery = total > 499 ? 0 : 49;
      sum.innerHTML = `
        <div class="card pad checkout-summary">
          <h3 class="m-0 mb-2">Order Summary</h3>
          <div class="line"><span>Items</span><b>${state.cart.length}</b></div>
          <div class="line"><span>Subtotal</span><b>₹${total.toFixed(2)}</b></div>
          <div class="line"><span>Delivery</span><b>₹${delivery.toFixed(2)}</b></div>
          <div class="line total"><span>To Pay</span><b>₹${(total + delivery).toFixed(2)}</b></div>
          <button class="btn mt-2" onclick="placeOrder()" style="width: 100%;">Place Order</button>
        </div>`;
    },
    
    async invoice(){
      if (!state.token) {
        window.location.href = 'login.html';
        return;
      }
      
      const root = document.querySelector('[data-invoice]');
      if(!root) return;
      
      // Get order from URL or localStorage
      const orderId = new URLSearchParams(location.search).get('orderId') || localStorage.getItem('lastOrderId');
      if (!orderId) {
        root.innerHTML = '<div class="card pad">No order found. Please check your order history.</div>';
        return;
      }
      
      try {
        const order = await apiCall(`/orders/${orderId}`);
        if (!order || !order.items || order.items.length === 0) {
          root.innerHTML = '<div class="card pad">Order details not found.</div>';
          return;
        }
        
        const total = order.total_amount + (order.delivery_charge || 0);
        root.innerHTML = `
          <div class="invoice">
            <header>
              <div><b>ApolloCare</b><div class="text-muted">Order Confirmation</div></div>
              <div>Order #${order.order_id}</div>
            </header>
            <table class="table">
              <thead>
                <tr><th>Item</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr>
              </thead>
              <tbody>
                ${order.items.map(i=>`
                  <tr>
                    <td>${i.name || 'Medicine'}</td>
                    <td>${i.quantity || 0}</td>
                    <td>₹${i.price || 0}</td>
                    <td>₹${((i.quantity || 0) * (i.price || 0)).toFixed(2)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            <div class="space-between mt-2">
              <div></div>
              <div class="checkout-summary">
                <div class="line"><span>Subtotal</span><b>₹${order.total_amount.toFixed(2)}</b></div>
                <div class="line"><span>Delivery</span><b>₹${(order.delivery_charge || 0).toFixed(2)}</b></div>
                <div class="line total"><span>Total</span><b>₹${total.toFixed(2)}</b></div>
              </div>
            </div>
          </div>`;
        // Clear cart after successful order
        await loadCart(); // Reload cart (should be empty now)
      } catch (error) {
        console.error('Error loading invoice:', error);
        root.innerHTML = `<div class="card pad">Error loading order details: ${error.message || 'Please try again later.'}</div>`;
      }
    },
    
    upload(){
      const drop = document.querySelector('[data-drop]');
      if(!drop) return;
      const input = drop.querySelector('input[type=file]');
      
      function setActive(v){ 
        drop.style.borderColor = v? 'var(--brand)' : 'var(--border)'; 
        drop.style.background = v? 'var(--brand-50)': '#fff'; 
      }
      
      ['dragenter','dragover'].forEach(e=> drop.addEventListener(e, ev=>{ ev.preventDefault(); setActive(true);}));
      ['dragleave','drop'].forEach(e=> drop.addEventListener(e, ev=>{ ev.preventDefault(); setActive(false);}));
      drop.addEventListener('drop', ev=>{ input.files = ev.dataTransfer.files; preview(); });
      drop.addEventListener('click', () => input.click());
      input.addEventListener('change', preview);
      
      function preview(){
        const file = input.files && input.files[0]; 
        if(!file) return;
        const area = document.querySelector('[data-preview]');
        const reader = new FileReader(); 
        reader.onload = ()=> area.innerHTML = `
          <div class="card pad">
            <div class="row">
              <img src="${reader.result}" style="width:72px;height:72px;border-radius:8px;object-fit:cover">
              <div>
                <b>${file.name}</b>
                <div class="text-muted">${Math.round(file.size/1024)} KB</div>
              </div>
            </div>
          </div>`;
        reader.readAsDataURL(file);
      }
      
      // Handle form submission
      const form = drop.closest('.card').querySelector('form');
      if (form) {
        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          if (!state.token) {
            toast('Please login to upload prescription', 'error');
            window.location.href = 'login.html';
            return;
          }
          
          const formData = new FormData();
          formData.append('file', input.files[0]);
          formData.append('doctorName', document.getElementById('doctorName')?.value || '');
          formData.append('hospital', document.getElementById('hospital')?.value || '');
          formData.append('notes', document.getElementById('notes')?.value || '');
          
          try {
            const response = await fetch(`${API_BASE}/prescriptions`, {
              method: 'POST',
              headers: { 'Authorization': `Bearer ${state.token}` },
              body: formData
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error);
            toast('Prescription uploaded successfully!');
            setTimeout(() => window.location.href = 'order-history.html', 1500);
          } catch (error) {
            toast(error.message || 'Upload failed', 'error');
          }
        });
      }
    },
    
    async verify(){
      if (!state.token || !state.staff) {
        window.location.href = 'staff-login.html';
        return;
      }
      
      const list = document.querySelector('[data-verify-list]');
      if(!list) return;
      
      try {
        const prescriptions = await apiCall('/staff/prescriptions');
        list.innerHTML = '';
        prescriptions.forEach(p => {
          const row = document.createElement('tr');
          const statusClass = p.status === 'Approved' ? 'success' : p.status === 'Rejected' ? 'danger' : 'warning';
          row.innerHTML = `
            <td>${p.prescription_id}</td>
            <td>${p.patient_name || 'N/A'}</td>
            <td><span class="status ${statusClass}">${p.status}</span></td>
            <td class="row-actions">
              <button class="chip" onclick="viewPrescription('${p.prescription_id}')">View</button>
              <button class="chip" onclick="updatePrescriptionStatus('${p.prescription_id}', 'Approved')">Approve</button>
              <button class="chip" onclick="updatePrescriptionStatus('${p.prescription_id}', 'Rejected')">Reject</button>
            </td>`;
          list.appendChild(row);
        });
      } catch (error) {
        console.error('Error loading prescriptions:', error);
        list.innerHTML = '<tr><td colspan="4">Error loading prescriptions</td></tr>';
      }
    },
    
    async history(){
      const body = document.querySelector('[data-history]');
      if(!body) return;
      
      if (!state.token) {
        body.innerHTML = '<tr><td colspan="5">Please login to view order history</td></tr>';
        return;
      }
      
      try {
        const orders = await apiCall('/orders');
        body.innerHTML = '';
        if (orders.length === 0) {
          body.innerHTML = '<tr><td colspan="5">No orders found</td></tr>';
        } else {
          orders.forEach(o => {
            const row = document.createElement('tr');
            const statusClass = o.status === 'Shipped' || o.status === 'Delivered' ? 'success' : o.status === 'Processing' ? 'warning' : 'warning';
            const userName = state.user ? `${state.user.first_name || state.user.firstName || ''} ${state.user.last_name || state.user.lastName || ''}`.trim() || 'You' : 'You';
            row.innerHTML = `
              <td><a href="invoice.html?orderId=${o.order_id}" style="color: var(--brand-700); text-decoration: underline;">${o.order_id}</a></td>
              <td>${new Date(o.created_at).toLocaleDateString()}</td>
              <td>${userName || 'You'}</td>
              <td><span class="status ${statusClass}">${o.status}</span></td>
              <td>₹${(parseFloat(o.total_amount) + parseFloat(o.delivery_charge || 0)).toFixed(2)}</td>`;
            body.appendChild(row);
          });
        }
      } catch (error) {
        console.error('Error loading orders:', error);
        body.innerHTML = '<tr><td colspan="5">Error loading orders</td></tr>';
      }
    },
    
    tracking(){
      const steps = ['Placed','Processing','Shipped','Out for Delivery','Delivered'];
      const statusMap = {
        'Processing': 1,
        'Shipped': 2,
        'Out for Delivery': 3,
        'Delivered': 4
      };
      const orderId = new URLSearchParams(location.search).get('orderId');
      const current = orderId ? 2 : 0; // Default to shipped if order exists
      const root = document.querySelector('[data-tracker]');
      if(!root) return;
      
      steps.forEach((s, i)=>{
        const el = document.createElement('div'); 
        el.className = 'step'+(i<=current?' active':''); 
        el.innerHTML = `<div class="dot"></div><div>${s}</div>`; 
        root.appendChild(el);
      });
    },
    
    async staff(){
      if (!state.token || !state.staff) {
        window.location.href = 'staff-login.html';
        return;
      }
      
      const k = document.querySelector('[data-kpi]');
      if(!k) return;
      
      try {
        const stats = await apiCall('/staff/dashboard');
        const items = [
          { label: 'Pending Rx', value: stats.pending_rx || 0 },
          { label: 'Orders Today', value: stats.orders_today || 0 },
          { label: 'Low Stock', value: stats.low_stock || 0 },
          { label: 'Expiring Soon', value: stats.expiring_soon || 0 },
        ];
        k.innerHTML = '';
        items.forEach(i=>{ 
          const el = document.createElement('div'); 
          el.className = 'item'; 
          el.innerHTML = `
            <div class="text-muted">${i.label}</div>
            <div style="font-weight:800;font-size:1.6rem">${i.value}</div>
          `; 
          k.appendChild(el); 
        });
        
        // Load recent orders
        try {
          const orders = await apiCall('/staff/orders');
          const recentOrdersEl = document.querySelector('[data-recent-orders]') || document.querySelector('.card.pad .stack');
          if (recentOrdersEl) {
            if (orders.length > 0) {
              recentOrdersEl.innerHTML = '';
              orders.slice(0, 5).forEach(o => {
                const statusClass = o.status === 'Shipped' || o.status === 'Delivered' ? 'success' : o.status === 'Processing' ? 'warning' : 'warning';
                const row = document.createElement('div');
                row.className = 'row';
                row.innerHTML = `
                  <div>
                    <div><b>Order #${o.order_id}</b></div>
                    <div class="text-muted">${o.user_name || 'Customer'} · ₹${(parseFloat(o.total_amount) + parseFloat(o.delivery_charge || 0)).toFixed(2)}</div>
                  </div>
                  <span class="status ${statusClass}">${o.status}</span>
                `;
                recentOrdersEl.appendChild(row);
              });
            } else {
              recentOrdersEl.innerHTML = '<div class="text-muted">No recent orders</div>';
            }
          }
        } catch (error) {
          console.error('Error loading recent orders:', error);
          const recentOrdersEl = document.querySelector('[data-recent-orders]');
          if (recentOrdersEl) {
            recentOrdersEl.innerHTML = '<div class="text-muted">Error loading orders</div>';
          }
        }
      } catch (error) {
        console.error('Error loading dashboard:', error);
      }
    },
    
    async 'staff-orders'(){
      if (!state.token || !state.staff) {
        window.location.href = 'staff-login.html';
        return;
      }
      
      const body = document.querySelector('[data-staff-orders]');
      if(!body) return;
      
      try {
        const orders = await apiCall('/staff/orders');
        body.innerHTML = '';
        if (orders.length === 0) {
          body.innerHTML = '<tr><td colspan="6">No orders found</td></tr>';
        } else {
          orders.forEach(o => {
            const row = document.createElement('tr');
            const statusClass = o.status === 'Shipped' || o.status === 'Delivered' ? 'success' : o.status === 'Processing' ? 'warning' : o.status === 'Cancelled' ? 'danger' : 'warning';
            row.innerHTML = `
              <td><a href="invoice.html?orderId=${o.order_id}" style="color: var(--brand-700);">${o.order_id}</a></td>
              <td>${new Date(o.created_at).toLocaleDateString()}</td>
              <td>${o.user_name || 'N/A'}</td>
              <td>₹${(parseFloat(o.total_amount) + parseFloat(o.delivery_charge || 0)).toFixed(2)}</td>
              <td><span class="status ${statusClass}">${o.status}</span></td>
              <td class="row-actions">
                <select onchange="updateOrderStatus('${o.order_id}', this.value)" style="padding: 0.4rem; border-radius: 8px; border: 1px solid var(--border);">
                  <option value="Processing" ${o.status === 'Processing' ? 'selected' : ''}>Processing</option>
                  <option value="Shipped" ${o.status === 'Shipped' ? 'selected' : ''}>Shipped</option>
                  <option value="Out for Delivery" ${o.status === 'Out for Delivery' ? 'selected' : ''}>Out for Delivery</option>
                  <option value="Delivered" ${o.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
                  <option value="Cancelled" ${o.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                </select>
              </td>
            `;
            body.appendChild(row);
          });
        }
        
        // Add search and filter functionality
        const searchInput = document.getElementById('searchOrders');
        const statusFilter = document.getElementById('statusFilter');
        
        if (searchInput) {
          searchInput.addEventListener('input', () => filterOrders(orders, body));
        }
        if (statusFilter) {
          statusFilter.addEventListener('change', () => filterOrders(orders, body));
        }
      } catch (error) {
        console.error('Error loading orders:', error);
        body.innerHTML = '<tr><td colspan="6">Error loading orders. Please login as staff.</td></tr>';
      }
    },
    
    async inventory(){
      if (!state.token || !state.staff) {
        window.location.href = 'staff-login.html';
        return;
      }
      
      const body = document.querySelector('[data-inventory]');
      if(!body) return;
      
      try {
        const medicines = await apiCall('/staff/inventory');
        body.innerHTML = '';
        medicines.forEach(m => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td>${m.medicine_id}</td>
            <td>${m.name}</td>
            <td>${m.brand}</td>
            <td>${m.batch || 'N/A'}</td>
            <td>${m.expiry_date || 'N/A'}</td>
            <td>${m.stock}</td>
            <td>₹${m.price}</td>
            <td class="row-actions">
              <button class="chip" onclick="updateStock(${m.id}, ${m.stock})">Update Stock</button>
            </td>`;
          body.appendChild(tr);
        });
      } catch (error) {
        console.error('Error loading inventory:', error);
        body.innerHTML = '<tr><td colspan="8">Error loading inventory</td></tr>';
      }
    },
  };

  function productCard(m){
    const el = document.createElement('div'); 
    el.className = 'card product';
    const medId = m.medicine_id || m.id;
    el.innerHTML = `
      <a class="thumb" href="medicine-details.html?id=${medId}">
        <img src="${m.image_url || m.image}" alt="${m.name}" style="width:100%;height:100%;object-fit:contain">
      </a>
      <div class="body">
        <div class="title">${m.name}</div>
        <div class="meta">${m.brand} · ${m.category_name || m.category}</div>
        <div class="space-between">
          <div class="price">₹${m.price}</div>
          <button class="chip" data-add ${m.stock < 1 ? 'disabled' : ''}>Add</button>
        </div>
      </div>`;
    el.querySelector('[data-add]').addEventListener('click', ()=> {
      if (m.stock < 1) {
        toast('Out of stock', 'error');
        return;
      }
      addToCart(m, 1);
    });
    return el;
  }

  // Login/Register handlers
  if (document.body.getAttribute('data-page') === 'login') {
    const form = document.querySelector('form');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        try {
          const data = await apiCall('/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
          });
          state.token = data.token;
          state.user = data.user;
          localStorage.setItem('token', data.token);
          localStorage.setItem('user', JSON.stringify(data.user));
          await loadCart(); // Load cart after login
          toast('Login successful!');
          setTimeout(() => window.location.href = 'index.html', 1000);
        } catch (error) {
          toast(error.message || 'Login failed', 'error');
        }
      });
    }
  }

  if (document.body.getAttribute('data-page') === 'register') {
    const form = document.querySelector('form');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = {
          firstName: document.getElementById('firstName').value,
          lastName: document.getElementById('lastName').value,
          email: document.getElementById('email').value,
          phone: document.getElementById('phone').value,
          password: document.getElementById('password').value,
          address: document.getElementById('address').value
        };
        
        if (data.password !== document.getElementById('confirmPassword').value) {
          toast('Passwords do not match', 'error');
          return;
        }
        
        try {
          const result = await apiCall('/register', {
            method: 'POST',
            body: JSON.stringify(data)
          });
          state.token = result.token;
          state.user = { id: result.userId, ...data };
          localStorage.setItem('token', result.token);
          localStorage.setItem('user', JSON.stringify(state.user));
          await loadCart(); // Load cart after registration
          toast('Registration successful!');
          setTimeout(() => window.location.href = 'index.html', 1000);
        } catch (error) {
          toast(error.message || 'Registration failed', 'error');
        }
      });
    }
  }

  // Place order function
  window.placeOrder = async function() {
    if (!state.token) {
      toast('Please login to place order', 'error');
      window.location.href = 'login.html';
      return;
    }
    
    await loadCart(); // Ensure cart is loaded
    if (state.cart.length === 0) {
      toast('Cart is empty', 'error');
      return;
    }
    
    const firstName = document.getElementById('firstName')?.value;
    const lastName = document.getElementById('lastName')?.value;
    const deliveryAddress = document.getElementById('address')?.value || '';
    const city = document.getElementById('city')?.value || '';
    const zip = document.getElementById('zip')?.value || '';
    const phone = document.getElementById('phone')?.value || '';
    const paymentMethod = document.querySelector('input[name="payment"]:checked')?.value || 'COD';
    
    if (!firstName || !lastName || !deliveryAddress || !phone) {
      toast('Please fill all required fields', 'error');
      return;
    }
    
    try {
      const result = await apiCall('/orders', {
        method: 'POST',
        body: JSON.stringify({ 
          firstName, 
          lastName,
          deliveryAddress, 
          city,
          zip,
          phone, 
          paymentMethod 
        })
      });
      
      localStorage.setItem('lastOrderId', result.orderId);
      toast('Order placed successfully!');
      await loadCart(); // Reload cart (should be empty now)
      setTimeout(() => window.location.href = `invoice.html?orderId=${result.orderId}`, 1500);
    } catch (error) {
      toast(error.message || 'Failed to place order', 'error');
    }
  };

  // Staff functions
  window.updatePrescriptionStatus = async function(id, status) {
    if (!state.token || !state.staff) {
      toast('Staff access required', 'error');
      window.location.href = 'staff-login.html';
      return;
    }
    
    try {
      await apiCall(`/staff/prescriptions/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status, verifiedBy: state.staff.id })
      });
      toast('Status updated');
      renderers.verify();
    } catch (error) {
      toast(error.message || 'Update failed', 'error');
    }
  };

  window.updateStock = async function(id, currentStock) {
    const newStock = prompt('Enter new stock:', currentStock);
    if (newStock === null) return;
    const stock = parseInt(newStock);
    if (isNaN(stock) || stock < 0) {
      toast('Invalid stock value', 'error');
      return;
    }
    
    try {
      await apiCall(`/staff/medicines/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ stock })
      });
      toast('Stock updated');
      renderers.inventory();
    } catch (error) {
      toast(error.message || 'Update failed', 'error');
    }
  };

  // Update order status (staff)
  window.updateOrderStatus = async function(orderId, newStatus) {
    if (!state.token || !state.staff) {
      toast('Staff access required. Please login as staff.', 'error');
      window.location.href = 'staff-login.html';
      return;
    }
    
    try {
      await apiCall(`/staff/orders/${orderId}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: newStatus })
      });
      toast(`Order status updated to ${newStatus}`);
      // Reload orders
      if (renderers['staff-orders']) {
        renderers['staff-orders']();
      }
    } catch (error) {
      toast(error.message || 'Failed to update status', 'error');
      // Reload to reset dropdown
      if (renderers['staff-orders']) {
        renderers['staff-orders']();
      }
    }
  };

  // Filter orders function
  function filterOrders(allOrders, body) {
    const searchTerm = (document.getElementById('searchOrders')?.value || '').toLowerCase();
    const statusFilter = document.getElementById('statusFilter')?.value || '';
    
    const filtered = allOrders.filter(o => {
      const matchesSearch = !searchTerm || 
        o.order_id.toLowerCase().includes(searchTerm) ||
        (o.user_name || '').toLowerCase().includes(searchTerm);
      const matchesStatus = !statusFilter || o.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
    
    body.innerHTML = '';
    if (filtered.length === 0) {
      body.innerHTML = '<tr><td colspan="6">No orders match your filters</td></tr>';
      return;
    }
    
    filtered.forEach(o => {
      const row = document.createElement('tr');
      const statusClass = o.status === 'Shipped' || o.status === 'Delivered' ? 'success' : o.status === 'Processing' ? 'warning' : o.status === 'Cancelled' ? 'danger' : 'warning';
      row.innerHTML = `
        <td><a href="invoice.html?orderId=${o.order_id}" style="color: var(--brand-700);">${o.order_id}</a></td>
        <td>${new Date(o.created_at).toLocaleDateString()}</td>
        <td>${o.user_name || 'N/A'}</td>
        <td>₹${(parseFloat(o.total_amount) + parseFloat(o.delivery_charge || 0)).toFixed(2)}</td>
        <td><span class="status ${statusClass}">${o.status}</span></td>
        <td class="row-actions">
          <select onchange="updateOrderStatus('${o.order_id}', this.value)" style="padding: 0.4rem; border-radius: 8px; border: 1px solid var(--border);">
            <option value="Processing" ${o.status === 'Processing' ? 'selected' : ''}>Processing</option>
            <option value="Shipped" ${o.status === 'Shipped' ? 'selected' : ''}>Shipped</option>
            <option value="Out for Delivery" ${o.status === 'Out for Delivery' ? 'selected' : ''}>Out for Delivery</option>
            <option value="Delivered" ${o.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
            <option value="Cancelled" ${o.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
          </select>
        </td>
      `;
      body.appendChild(row);
    });
  }

  // Profile page handler
  if (document.body.getAttribute('data-page') === 'profile') {
    async function loadProfile() {
      if (!state.token) {
        window.location.href = 'login.html';
        return;
      }
      
      try {
        const user = await apiCall('/profile');
        document.getElementById('firstName').value = user.first_name || '';
        document.getElementById('lastName').value = user.last_name || '';
        document.getElementById('email').value = user.email || '';
        document.getElementById('phone').value = user.phone || '';
        document.getElementById('address').value = user.address || '';
        
        const nameEl = document.querySelector('h3.m-0');
        const emailEl = document.querySelector('p.text-muted');
        if (nameEl) nameEl.textContent = `${user.first_name} ${user.last_name}`;
        if (emailEl) emailEl.textContent = user.email;
      } catch (error) {
        console.error('Error loading profile:', error);
        if (error.message.includes('Unauthorized')) {
          window.location.href = 'login.html';
        }
      }
    }
    
    loadProfile();
    
    const form = document.querySelector('form');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!state.token) {
          toast('Please login', 'error');
          window.location.href = 'login.html';
          return;
        }
        
        try {
          await apiCall('/profile', {
            method: 'PATCH',
            body: JSON.stringify({
              firstName: document.getElementById('firstName').value,
              lastName: document.getElementById('lastName').value,
              phone: document.getElementById('phone').value,
              address: document.getElementById('address').value
            })
          });
          toast('Profile updated successfully!');
          loadProfile();
        } catch (error) {
          toast(error.message || 'Update failed', 'error');
        }
      });
    }
  }

  let carouselCurrentSlide = 0;
  let carouselInterval;

  function initCarousel(){
    const carousel = document.getElementById('heroCarousel');
    if(!carousel) return;
    
    const slides = carousel.querySelectorAll('.carousel-slide');
    const dots = carousel.querySelectorAll('.carousel-dots .dot');
    
    function showSlide(index){
      slides.forEach((slide, i) => {
        slide.classList.toggle('active', i === index);
      });
      dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === index);
      });
      carouselCurrentSlide = index;
    }
    
    function nextSlide(){
      const next = (carouselCurrentSlide + 1) % slides.length;
      showSlide(next);
    }
    
    function prevSlide(){
      const prev = carouselCurrentSlide === 0 ? slides.length - 1 : carouselCurrentSlide - 1;
      showSlide(prev);
    }
    
    window.changeSlide = function(direction) {
      clearInterval(carouselInterval);
      if(direction === 1) nextSlide();
      else if(direction === -1) prevSlide();
      carouselInterval = setInterval(nextSlide, 4000);
    };
    
    window.currentSlide = function(index) {
      clearInterval(carouselInterval);
      showSlide(index - 1);
      carouselInterval = setInterval(nextSlide, 4000);
    };
    
    carouselInterval = setInterval(nextSlide, 4000);
  }

  // Staff login handler
  if (document.body.getAttribute('data-page') === 'staff-login') {
    const form = document.getElementById('staffLoginForm');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        try {
          const data = await apiCall('/staff/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
          });
          state.token = data.token;
          state.staff = data.staff;
          localStorage.setItem('token', data.token);
          localStorage.setItem('staff', JSON.stringify(data.staff));
          toast('Staff login successful!');
          setTimeout(() => window.location.href = 'staff-dashboard.html', 1000);
        } catch (error) {
          toast(error.message || 'Login failed', 'error');
        }
      });
    }
  }

  function init(){
    injectLayout();
    const page = document.body.getAttribute('data-page');
    if(page && renderers[page]) {
      if (renderers[page].constructor.name === 'AsyncFunction') {
        renderers[page]().catch(err => console.error('Page render error:', err));
      } else {
        renderers[page]();
      }
    }
    initCarousel();
  }

  document.addEventListener('DOMContentLoaded', init);
})();

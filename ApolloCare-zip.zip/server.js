const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const dbPath = path.join(__dirname, 'database', 'apollocare.db');

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Database connection
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error connecting to database:', err.message);
        process.exit(1);
    }
    console.log('Connected to SQLite database');
});

// Helper functions
const hashPassword = (password) => Buffer.from(password).toString('base64');
const comparePassword = (plain, hashed) => hashPassword(plain) === hashed;
const generateToken = () => crypto.randomBytes(32).toString('hex');

// File upload configuration
const upload = multer({
    dest: 'uploads/prescriptions/',
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
    fileFilter: (req, file, cb) => {
        const allowedTypes = /jpeg|jpg|png|pdf/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);
        if (extname && mimetype) {
            return cb(null, true);
        }
        cb(new Error('Only image and PDF files are allowed'));
    }
});

// Authentication middleware
const authenticate = (req, res, next) => {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    
    db.get('SELECT * FROM sessions WHERE token = ? AND expires_at > datetime("now")', [token], (err, session) => {
        if (err || !session) {
            return res.status(401).json({ error: 'Invalid or expired token' });
        }
        req.userId = session.user_id;
        next();
    });
};

// Staff authentication middleware (staff sessions have negative user_id)
const authenticateStaff = (req, res, next) => {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    
    db.get('SELECT * FROM sessions WHERE token = ? AND expires_at > datetime("now")', [token], (err, session) => {
        if (err || !session) {
            return res.status(401).json({ error: 'Invalid or expired token' });
        }
        // Staff sessions have negative user_id
        if (session.user_id > 0) {
            return res.status(403).json({ error: 'Staff access required' });
        }
        req.staffId = Math.abs(session.user_id);
        next();
    });
};

// ==================== AUTHENTICATION ====================

// Register
app.post('/api/register', (req, res) => {
    const { firstName, lastName, email, phone, password, address } = req.body;
    
    if (!firstName || !lastName || !email || !password) {
        return res.status(400).json({ error: 'Missing required fields' });
    }
    
    db.run(
        'INSERT INTO users (first_name, last_name, email, phone, password, address) VALUES (?, ?, ?, ?, ?, ?)',
        [firstName, lastName, email, phone || null, hashPassword(password), address || null],
        function(err) {
            if (err) {
                if (err.message.includes('UNIQUE constraint')) {
                    return res.status(400).json({ error: 'Email already exists' });
                }
                return res.status(500).json({ error: err.message });
            }
            
            const token = generateToken();
            const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
            
            db.run(
                'INSERT INTO sessions (user_id, token, expires_at) VALUES (?, ?, ?)',
                [this.lastID, token, expiresAt],
                (err) => {
                    if (err) {
                        return res.status(500).json({ error: 'Failed to create session' });
                    }
                    res.json({ token, userId: this.lastID, message: 'Registration successful' });
                }
            );
        }
    );
});

// Login
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    
    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password required' });
    }
    
    db.get('SELECT * FROM users WHERE email = ?', [email], (err, user) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (!user || !comparePassword(password, user.password)) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        const token = generateToken();
        const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
        
        db.run(
            'INSERT INTO sessions (user_id, token, expires_at) VALUES (?, ?, ?)',
            [user.id, token, expiresAt],
            (err) => {
                if (err) {
                    return res.status(500).json({ error: 'Failed to create session' });
                }
                res.json({ 
                    token, 
                    userId: user.id,
                    user: {
                        id: user.id,
                        firstName: user.first_name,
                        lastName: user.last_name,
                        email: user.email,
                        phone: user.phone,
                        address: user.address
                    }
                });
            }
        );
    });
});

// Staff Login
app.post('/api/staff/login', (req, res) => {
    const { email, password } = req.body;
    
    db.get('SELECT * FROM staff WHERE email = ?', [email], (err, staff) => {
        if (err || !staff || !comparePassword(password, staff.password)) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        const token = generateToken();
        const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
        
        // Store staff session (using sessions table with negative user_id to distinguish)
        db.run(
            'INSERT INTO sessions (user_id, token, expires_at) VALUES (?, ?, ?)',
            [-staff.id, token, expiresAt],
            (err) => {
                if (err) {
                    return res.status(500).json({ error: 'Failed to create session' });
                }
                res.json({ token, staff: { id: staff.id, name: staff.name, role: staff.role } });
            }
        );
    });
});

// ==================== MEDICINES ====================

// Get all medicines
app.get('/api/medicines', (req, res) => {
    const { q, category } = req.query;
    let query = `
        SELECT m.*, c.name as category_name 
        FROM medicines m 
        LEFT JOIN categories c ON m.category_id = c.id
        WHERE 1=1
    `;
    const params = [];
    
    if (q) {
        query += ` AND (m.name LIKE ? OR m.brand LIKE ? OR m.composition LIKE ? OR c.name LIKE ?)`;
        const searchTerm = `%${q}%`;
        params.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }
    
    if (category && category !== 'All') {
        query += ` AND c.name = ?`;
        params.push(category);
    }
    
    query += ` ORDER BY m.name`;
    
    db.all(query, params, (err, medicines) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(medicines);
    });
});

// Get medicine by ID
app.get('/api/medicines/:id', (req, res) => {
    const { id } = req.params;
    
    db.get(`
        SELECT m.*, c.name as category_name 
        FROM medicines m 
        LEFT JOIN categories c ON m.category_id = c.id
        WHERE m.medicine_id = ? OR m.id = ?
    `, [id, id], (err, medicine) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (!medicine) {
            return res.status(404).json({ error: 'Medicine not found' });
        }
        res.json(medicine);
    });
});

// Get categories
app.get('/api/categories', (req, res) => {
    db.all('SELECT * FROM categories ORDER BY name', [], (err, categories) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(categories);
    });
});

// ==================== CART ====================

// Get user cart
app.get('/api/cart', authenticate, (req, res) => {
    db.all(`
        SELECT c.*, m.medicine_id, m.name, m.price, m.image_url, m.stock
        FROM cart c
        JOIN medicines m ON c.medicine_id = m.id
        WHERE c.user_id = ?
        ORDER BY c.created_at DESC
    `, [req.userId], (err, items) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(items);
    });
});

// Add to cart
app.post('/api/cart', authenticate, (req, res) => {
    const { medicineId, quantity } = req.body;
    
    if (!medicineId || !quantity || quantity < 1) {
        return res.status(400).json({ error: 'Medicine ID and quantity required' });
    }
    
    // First check if medicine exists and has stock
    db.get('SELECT * FROM medicines WHERE medicine_id = ? OR id = ?', [medicineId, medicineId], (err, medicine) => {
        if (err || !medicine) {
            return res.status(404).json({ error: 'Medicine not found' });
        }
        
        // Check if item already in cart
        db.get('SELECT * FROM cart WHERE user_id = ? AND medicine_id = ?', [req.userId, medicine.id], (err, existing) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            
            if (existing) {
                // Update quantity
                const newQty = existing.quantity + quantity;
                if (newQty > medicine.stock) {
                    return res.status(400).json({ error: 'Insufficient stock' });
                }
                db.run(
                    'UPDATE cart SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
                    [newQty, existing.id],
                    (err) => {
                        if (err) {
                            return res.status(500).json({ error: err.message });
                        }
                        res.json({ message: 'Cart updated' });
                    }
                );
            } else {
                // Add new item
                if (quantity > medicine.stock) {
                    return res.status(400).json({ error: 'Insufficient stock' });
                }
                db.run(
                    'INSERT INTO cart (user_id, medicine_id, quantity) VALUES (?, ?, ?)',
                    [req.userId, medicine.id, quantity],
                    (err) => {
                        if (err) {
                            return res.status(500).json({ error: err.message });
                        }
                        res.json({ message: 'Added to cart' });
                    }
                );
            }
        });
    });
});

// Update cart item quantity
app.patch('/api/cart/:id', authenticate, (req, res) => {
    const { id } = req.params;
    const { quantity } = req.body;
    
    if (!quantity || quantity < 1) {
        return res.status(400).json({ error: 'Valid quantity required' });
    }
    
    // Check stock availability
    db.get(`
        SELECT c.*, m.stock 
        FROM cart c
        JOIN medicines m ON c.medicine_id = m.id
        WHERE c.id = ? AND c.user_id = ?
    `, [id, req.userId], (err, item) => {
        if (err || !item) {
            return res.status(404).json({ error: 'Cart item not found' });
        }
        
        if (quantity > item.stock) {
            return res.status(400).json({ error: 'Insufficient stock' });
        }
        
        db.run(
            'UPDATE cart SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?',
            [quantity, id, req.userId],
            (err) => {
                if (err) {
                    return res.status(500).json({ error: err.message });
                }
                res.json({ message: 'Cart updated' });
            }
        );
    });
});

// Remove from cart
app.delete('/api/cart/:id', authenticate, (req, res) => {
    const { id } = req.params;
    
    db.run('DELETE FROM cart WHERE id = ? AND user_id = ?', [id, req.userId], function(err) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Cart item not found' });
        }
        res.json({ message: 'Item removed from cart' });
    });
});

// Clear cart (after order placement)
app.delete('/api/cart', authenticate, (req, res) => {
    db.run('DELETE FROM cart WHERE user_id = ?', [req.userId], (err) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({ message: 'Cart cleared' });
    });
});

// ==================== ORDERS ====================

// Create order
app.post('/api/orders', authenticate, (req, res) => {
    const { deliveryAddress, phone, paymentMethod, firstName, lastName, city, zip } = req.body;
    
    // Get cart items from database
    db.all(`
        SELECT c.*, m.id as medicine_db_id, m.medicine_id, m.name, m.price, m.stock
        FROM cart c
        JOIN medicines m ON c.medicine_id = m.id
        WHERE c.user_id = ?
    `, [req.userId], (err, cartItems) => {
        if (err) {
            console.error('Error fetching cart items:', err);
            return res.status(500).json({ error: err.message });
        }
        
        if (!cartItems || cartItems.length === 0) {
            return res.status(400).json({ error: 'Cart is empty' });
        }
    
        // Validate stock for all items
        for (let item of cartItems) {
            if (item.quantity > item.stock) {
                return res.status(400).json({ error: `Insufficient stock for ${item.name}` });
            }
        }
        
        // Calculate total
        let total = 0;
        cartItems.forEach(item => {
            total += item.price * item.quantity;
        });
        
        const deliveryCharge = total > 499 ? 0 : 49;
        const orderId = 'ORD' + Date.now();
        const fullAddress = `${deliveryAddress}, ${city}, ${zip}`;
        
        db.serialize(() => {
            db.run('BEGIN TRANSACTION');
            
            // Create order
            db.run(
                `INSERT INTO orders (order_id, user_id, total_amount, delivery_charge, payment_method, delivery_address, phone, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'Processing')`,
                [orderId, req.userId, total, deliveryCharge, paymentMethod || 'COD', fullAddress, phone],
                function(err) {
                    if (err) {
                        db.run('ROLLBACK');
                        return res.status(500).json({ error: err.message });
                    }
                    
                    const orderDbId = this.lastID;
                    const stmt = db.prepare('INSERT INTO order_items (order_id, medicine_id, quantity, price) VALUES (?, ?, ?, ?)');
                    let completed = 0;
                    
                    cartItems.forEach((item) => {
                        // Use medicine_db_id (which is m.id from the join) or medicine_id from cart
                        const medicineDbId = item.medicine_db_id || item.medicine_id;
                        stmt.run(orderDbId, medicineDbId, item.quantity, item.price, (err) => {
                            if (err) {
                                console.error('Error inserting order item:', err);
                                db.run('ROLLBACK');
                                stmt.finalize();
                                return res.status(500).json({ error: err.message });
                            }
                            
                            // Update stock
                            db.run('UPDATE medicines SET stock = stock - ? WHERE id = ?', [item.quantity, medicineDbId], (err) => {
                                if (err) {
                                    console.error('Error updating stock:', err);
                                }
                            });
                            
                            completed++;
                            if (completed === cartItems.length) {
                                stmt.finalize();
                                
                                // Clear cart after successful order
                                db.run('DELETE FROM cart WHERE user_id = ?', [req.userId], (err) => {
                                    if (err) {
                                        console.error('Error clearing cart:', err);
                                    }
                                    db.run('COMMIT', (err) => {
                                        if (err) {
                                            console.error('Error committing transaction:', err);
                                            return res.status(500).json({ error: err.message });
                                        }
                                        res.json({ 
                                            orderId, 
                                            total: total + deliveryCharge,
                                            message: 'Order placed successfully' 
                                        });
                                    });
                                });
                            }
                        });
                    });
                }
            );
        });
    });
});

// Get user orders
app.get('/api/orders', authenticate, (req, res) => {
    db.all(`
        SELECT o.*, 
               u.first_name || ' ' || u.last_name as user_name
        FROM orders o
        JOIN users u ON o.user_id = u.id
        WHERE o.user_id = ?
        ORDER BY o.created_at DESC
    `, [req.userId], (err, orders) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(orders);
    });
});

// Get order details
app.get('/api/orders/:id', authenticate, (req, res) => {
    const { id } = req.params;
    
    db.get(`
        SELECT o.*, u.first_name, u.last_name, u.email, u.phone
        FROM orders o
        JOIN users u ON o.user_id = u.id
        WHERE o.order_id = ? AND o.user_id = ?
    `, [id, req.userId], (err, order) => {
        if (err) {
            console.error('Error fetching order:', err);
            return res.status(500).json({ error: err.message });
        }
        if (!order) {
            return res.status(404).json({ error: 'Order not found' });
        }
        
        db.all(`
            SELECT oi.*, m.name, m.image_url, m.medicine_id
            FROM order_items oi
            JOIN medicines m ON oi.medicine_id = m.id
            WHERE oi.order_id = ?
        `, [order.id], (err, items) => {
            if (err) {
                console.error('Error fetching order items:', err);
                return res.status(500).json({ error: err.message });
            }
            if (!items || items.length === 0) {
                console.error('No items found for order:', order.id);
                return res.status(404).json({ error: 'Order items not found' });
            }
            res.json({ ...order, items: items || [] });
        });
    });
});

// Get all orders (staff)
app.get('/api/staff/orders', authenticateStaff, (req, res) => {
    db.all(`
        SELECT o.*, u.first_name || ' ' || u.last_name as user_name
        FROM orders o
        JOIN users u ON o.user_id = u.id
        ORDER BY o.created_at DESC
    `, [], (err, orders) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(orders);
    });
});

// Update order status (staff)
app.patch('/api/staff/orders/:id', authenticateStaff, (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    
    const validStatuses = ['Processing', 'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled'];
    if (!status || !validStatuses.includes(status)) {
        return res.status(400).json({ error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` });
    }
    
    db.run(
        'UPDATE orders SET status = ? WHERE order_id = ?',
        [status, id],
        function(err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            if (this.changes === 0) {
                return res.status(404).json({ error: 'Order not found' });
            }
            res.json({ message: 'Order status updated successfully', status });
        }
    );
});

// ==================== PRESCRIPTIONS ====================

// Upload prescription
app.post('/api/prescriptions', authenticate, upload.single('file'), (req, res) => {
    const { doctorName, hospital, notes } = req.body;
    const file = req.file;
    
    if (!file) {
        return res.status(400).json({ error: 'File required' });
    }
    
    const prescriptionId = 'RX-' + Date.now();
    const filePath = file.path;
    const fileName = file.originalname;
    
    db.run(
        `INSERT INTO prescriptions (prescription_id, user_id, doctor_name, hospital, file_path, file_name, notes, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')`,
        [prescriptionId, req.userId, doctorName, hospital, filePath, fileName, notes],
        function(err) {
            if (err) {
                fs.unlinkSync(filePath, () => {});
                return res.status(500).json({ error: err.message });
            }
            res.json({ prescriptionId, message: 'Prescription uploaded successfully' });
        }
    );
});

// Get user prescriptions
app.get('/api/prescriptions', authenticate, (req, res) => {
    db.all(
        'SELECT * FROM prescriptions WHERE user_id = ? ORDER BY created_at DESC',
        [req.userId],
        (err, prescriptions) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json(prescriptions);
        }
    );
});

// Get all prescriptions (staff)
app.get('/api/staff/prescriptions', authenticateStaff, (req, res) => {
    db.all(`
        SELECT p.*, u.first_name || ' ' || u.last_name as patient_name
        FROM prescriptions p
        JOIN users u ON p.user_id = u.id
        ORDER BY p.created_at DESC
    `, [], (err, prescriptions) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(prescriptions);
    });
});

// Update prescription status
app.patch('/api/staff/prescriptions/:id', authenticateStaff, (req, res) => {
    const { id } = req.params;
    const { status, verifiedBy } = req.body;
    
    if (!['Pending', 'Approved', 'Rejected'].includes(status)) {
        return res.status(400).json({ error: 'Invalid status' });
    }
    
    db.run(
        'UPDATE prescriptions SET status = ?, verified_by = ? WHERE prescription_id = ?',
        [status, verifiedBy, id],
        function(err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json({ message: 'Prescription status updated' });
        }
    );
});

// ==================== INVENTORY ====================

// Get inventory (staff)
app.get('/api/staff/inventory', authenticateStaff, (req, res) => {
    db.all(`
        SELECT m.*, c.name as category_name
        FROM medicines m
        LEFT JOIN categories c ON m.category_id = c.id
        ORDER BY m.name
    `, [], (err, medicines) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(medicines);
    });
});

// Update medicine stock
app.patch('/api/staff/medicines/:id', authenticateStaff, (req, res) => {
    const { id } = req.params;
    const { stock, price } = req.body;
    
    const updates = [];
    const params = [];
    
    if (stock !== undefined) {
        updates.push('stock = ?');
        params.push(stock);
    }
    if (price !== undefined) {
        updates.push('price = ?');
        params.push(price);
    }
    
    if (updates.length === 0) {
        return res.status(400).json({ error: 'No fields to update' });
    }
    
    params.push(id);
    
    db.run(
        `UPDATE medicines SET ${updates.join(', ')} WHERE id = ?`,
        params,
        function(err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json({ message: 'Medicine updated successfully' });
        }
    );
});

// ==================== USER PROFILE ====================

// Get user profile
app.get('/api/profile', authenticate, (req, res) => {
    db.get('SELECT id, first_name, last_name, email, phone, address FROM users WHERE id = ?', [req.userId], (err, user) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json(user);
    });
});

// Update user profile
app.patch('/api/profile', authenticate, (req, res) => {
    const { firstName, lastName, phone, address } = req.body;
    
    const updates = [];
    const params = [];
    
    if (firstName) { updates.push('first_name = ?'); params.push(firstName); }
    if (lastName) { updates.push('last_name = ?'); params.push(lastName); }
    if (phone) { updates.push('phone = ?'); params.push(phone); }
    if (address) { updates.push('address = ?'); params.push(address); }
    
    if (updates.length === 0) {
        return res.status(400).json({ error: 'No fields to update' });
    }
    
    params.push(req.userId);
    
    db.run(
        `UPDATE users SET ${updates.join(', ')} WHERE id = ?`,
        params,
        function(err) {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json({ message: 'Profile updated successfully' });
        }
    );
});

// ==================== DASHBOARD STATS ====================

// Get dashboard stats
app.get('/api/staff/dashboard', authenticateStaff, (req, res) => {
    db.get(`
        SELECT 
            (SELECT COUNT(*) FROM prescriptions WHERE status = 'Pending') as pending_rx,
            (SELECT COUNT(*) FROM orders WHERE date(created_at) = date('now')) as orders_today,
            (SELECT COUNT(*) FROM medicines WHERE stock < 50) as low_stock,
            (SELECT COUNT(*) FROM medicines WHERE expiry_date < date('now', '+30 days')) as expiring_soon
    `, [], (err, stats) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(stats);
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`ApolloCare server running on http://localhost:${PORT}`);
    console.log(`Make sure the database is initialized by running: node database/init.js`);
});



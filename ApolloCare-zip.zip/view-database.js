// Quick script to view database tables and data
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'database', 'apollocare.db');

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
        process.exit(1);
    }
    console.log('Connected to database successfully!\n');
});

// Get all table names
db.all("SELECT name FROM sqlite_master WHERE type='table'", [], (err, tables) => {
    if (err) {
        console.error('Error:', err.message);
        db.close();
        return;
    }
    
    console.log('📊 DATABASE TABLES:');
    console.log('='.repeat(50));
    tables.forEach((table, index) => {
        console.log(`${index + 1}. ${table.name}`);
    });
    console.log('='.repeat(50));
    console.log(`\nTotal tables: ${tables.length}\n`);
    
    // Show row counts for each table
    let completed = 0;
    tables.forEach(table => {
        db.get(`SELECT COUNT(*) as count FROM ${table.name}`, [], (err, row) => {
            if (!err) {
                console.log(`📋 ${table.name}: ${row.count} rows`);
            }
            completed++;
            if (completed === tables.length) {
                console.log('\n');
                showSampleData();
            }
        });
    });
});

function showSampleData() {
    console.log('📦 SAMPLE DATA:');
    console.log('='.repeat(50));
    
    // Show users
    db.all('SELECT id, first_name, last_name, email FROM users', [], (err, rows) => {
        if (!err && rows.length > 0) {
            console.log('\n👥 USERS:');
            //rows.forEach(u => 
                console.table(rows)
            //);
        }
    });
    
    // Show medicines
    db.all('SELECT medicine_id, name, price, stock FROM medicines', [], (err, rows) => {
        if (!err && rows.length > 0) {
            console.log('\n💊 MEDICINES:');
            //rows.forEach(m => 
                console.table(rows)
            //);
        }
    });
    
    // Show categories
    db.all('SELECT * FROM categories', [], (err, rows) => {
        if (!err && rows.length > 0) {
            console.log('\n📂 CATEGORIES:');
            //rows.forEach(c => 
                console.table(rows);
        }
    });
    
    // Show orders
    db.all('SELECT order_id, total_amount, status FROM orders', [], (err, rows) => {
        if (!err && rows.length > 0) {
            console.log('\n🛒 ORDERS:');
            //rows.forEach(o => 
                console.table(rows);
                //log(`  ${o.order_id}: ₹${o.total_amount} (${o.status})`));
        } else {
            console.log('\n🛒 ORDERS: No orders yet');
        }
        db.close();
    });
    //show cart
    db.all('SELECT * FROM cart', [], (err, rows) => {
        if (!err && rows.length > 0) {
            console.log('\nCART:');
            //rows.forEach(c => 
                console.table(rows);
        }
    });
    //Show order_items
    db.all('SELECT * FROM order_items', [], (err, rows) => {
        if (!err && rows.length > 0) {
            console.log('\n📂 ORDER ITEMS:');
            //rows.forEach(c => 
                console.table(rows);
        }
    });
    //Show sessions
    db.all('SELECT * FROM sessions', [], (err, rows) => {
        if (!err && rows.length > 0) {
            console.log('\n📂 SESSIONS:');
            //rows.forEach(c => 
                console.table(rows);
        }
    });
    //Show sqlite_sequence
    db.all('SELECT * FROM sqlite_sequence', [], (err, rows) => {
        if (!err && rows.length > 0) {
            console.log('\n📂 SQLITE SEQUENCE:');
            //rows.forEach(c => 
                console.table(rows);
        }
    });
    //Show staff
    db.all('SELECT * FROM staff', [], (err, rows) => {
        if (!err && rows.length > 0) {
            console.log('\n STAFF:');
            //rows.forEach(c => 
                console.table(rows);
        }
    });
    //Show prescriptions
    db.all('SELECT * FROM prescriptions', [], (err, rows) => {
        if (!err && rows.length > 0) {
            console.log('\n PRESCRIPTIONS:');
            //rows.forEach(c => 
                console.table(rows);
        }
    });
}

